# JAX AUTO Delivery Studio — Final Ultimate

React + Vite + JSZip + QRCode.

## Vercel Settings
- Build command: npm run build
- Output directory: dist

## Main Features
- Delivery Studio
- Promo Studio
- Compare Studio
- Review Studio
- Stats Studio
- Finance Poster
- Collage Studio
- Logo upload
- QR code
- Batch ZIP export
- Autosave preset
- Multiple ratios
- Image filters
- Privacy blur / face hide box
