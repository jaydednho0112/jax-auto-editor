
import React, { useEffect, useMemo, useRef, useState } from "react";
import { createRoot } from "react-dom/client";
import JSZip from "jszip";
import QRCode from "qrcode";
import "./styles.css";

const RATIOS = {
  "IG 4:5": [1080, 1350],
  "Square 1:1": [1080, 1080],
  "Story 9:16": [1080, 1920],
  "Xiaohongshu 3:4": [1080, 1440],
  "WhatsApp Status": [1080, 1920],
  "Reel Cover 9:16": [1080, 1920]
};

const MODELS = [
  "JAECOO J7", "JAECOO J5", "PROTON X50", "PROTON X70", "PROTON S70",
  "TIGGO CROSS", "CHERY TIGGO 7 PRO", "CHERY TIGGO 8 PRO", "CHERY OMODA 5"
];

const DEFAULT = {
  mode: "delivery",
  ratio: "IG 4:5",
  template: "modern",
  theme: "blackgold",
  model: "CHERY TIGGO 8 PRO",
  title: "DELIVERED",
  subtitle: "SUCCESSFULLY",
  name: "Jayden Ho",
  brand: "JAX AUTO",
  watermark: "@jaydenho.auto",
  whatsapp: "https://wa.me/60170000000",
  promoTitle: "FREE GIFTS INCLUDED",
  promoOffer: "RM 988 / MONTH",
  gifts: "40% VIGMA Tinted Voucher\nFull Tank Petrol\nGoodies Bag Package (10 Items)\nRFID\nTouch 'n Go Card\nOriginal Carmat\nPolish & Wax\nCar Wash",
  compareTitle: "Which one suits you better?",
  leftModel: "PROTON X50",
  rightModel: "JAECOO J7",
  compareList: "Budget friendly | Premium SUV feel\nCity drive | Family / long distance\nCompact size | Bigger cabin\nPetrol saving | Comfort & safety",
  reviewTitle: "CUSTOMER REVIEW",
  rating: "★★★★★",
  reviewText: "Fast response, smooth loan process and good service. Recommended!",
  customerName: "Happy Customer",
  achievementTitle: "TOP SALES ADVISOR",
  achievementSub: "Thank you for your trust & support",
  statsTitle: "THIS MONTH DELIVERY",
  statsNumber: "44",
  statsLabel: "UNITS REGISTERED",
  loanAmount: "135000",
  interestRate: "2.86",
  tenureMonths: "108",
  brightness: 106,
  contrast: 112,
  saturation: 108,
  vignette: 28,
  showLogo: true,
  showWatermark: true,
  showQR: false,
  blurEnabled: false,
  faceHideEnabled: false
};

function loadState() {
  try { return { ...DEFAULT, ...(JSON.parse(localStorage.getItem("jax_final_state")) || {}) }; }
  catch { return DEFAULT; }
}

function fileToImage(file) {
  return new Promise(resolve => {
    const r = new FileReader();
    r.onload = e => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.src = e.target.result;
    };
    r.readAsDataURL(file);
  });
}

function monthlyPayment(P, annualRate, n) {
  const r = Number(annualRate) / 100 / 12;
  const p = Number(P);
  const m = Number(n);
  if (!p || !m) return 0;
  if (!r) return p / m;
  return (p * r * Math.pow(1 + r, m)) / (Math.pow(1 + r, m) - 1);
}

function fitText(ctx, text, x, y, maxW, size, font = "Arial", weight = "700", align = "left", color = "#fff") {
  ctx.save();
  ctx.textAlign = align;
  ctx.fillStyle = color;
  let s = Number(size);
  ctx.font = `${weight} ${s}px ${font}`;
  while (ctx.measureText(String(text)).width > maxW && s > 10) {
    s -= 2;
    ctx.font = `${weight} ${s}px ${font}`;
  }
  ctx.fillText(String(text), x, y);
  ctx.restore();
  return s;
}

function wrapText(ctx, text, x, y, maxW, size, lineH, color = "#fff", weight = "500") {
  ctx.save();
  ctx.fillStyle = color;
  ctx.font = `${weight} ${size}px Arial`;
  const words = String(text).split(" ");
  let line = "";
  for (let i = 0; i < words.length; i++) {
    const test = line + words[i] + " ";
    if (ctx.measureText(test).width > maxW && i > 0) {
      ctx.fillText(line, x, y);
      line = words[i] + " ";
      y += lineH;
    } else line = test;
  }
  ctx.fillText(line, x, y);
  ctx.restore();
}

function App() {
  const canvasRef = useRef(null);
  const [state, setState] = useState(loadState);
  const [imgs, setImgs] = useState({ main:null, second:null, logo:null, batch:[] });
  const [qrImg, setQrImg] = useState(null);
  const [pos, setPos] = useState({
    title:{x:85,y:105}, logo:{x:1010,y:70}, watermark:{x:1010,y:1292},
    thanks:{x:70,y:1200}, name:{x:1010,y:1200}, box:{x:70,y:740,w:940,h:390},
    blur:{x:430,y:850,w:260,h:90}, face:{x:360,y:250,w:220,h:220}, qr:{x:790,y:1040,w:160,h:160}
  });

  useEffect(() => { localStorage.setItem("jax_final_state", JSON.stringify(state)); }, [state]);
  useEffect(() => { QRCode.toDataURL(state.whatsapp || "https://wa.me/", { margin: 1, width: 360 }).then(setQrImg); }, [state.whatsapp]);
  useEffect(() => { render(); }, [state, imgs, pos, qrImg]);

  function update(k, v) { setState(s => ({ ...s, [k]: v })); }

  async function upload(e, key) {
    const f = e.target.files?.[0];
    if (!f) return;
    const img = await fileToImage(f);
    setImgs(v => ({ ...v, [key]: img }));
  }

  async function uploadBatch(e) {
    const files = Array.from(e.target.files || []).slice(0, 50);
    const batch = [];
    for (const f of files) batch.push(await fileToImage(f));
    setImgs(v => ({ ...v, batch }));
  }

  function setCanvasSize() {
    const c = canvasRef.current;
    const [w,h] = RATIOS[state.ratio] || RATIOS["IG 4:5"];
    c.width = w; c.height = h;
    if (pos.watermark.y > h || pos.name.y > h) {
      setPos(p => ({...p, watermark:{...p.watermark,y:h-58}, thanks:{...p.thanks,y:h-150}, name:{x:w-70,y:h-150}, logo:{...p.logo,x:w-70}}));
    }
  }

  function cover(ctx, img, x=0, y=0, w=ctx.canvas.width, h=ctx.canvas.height) {
    const sc = Math.max(w/img.width, h/img.height);
    const nw = img.width*sc, nh = img.height*sc;
    ctx.drawImage(img, x+(w-nw)/2, y+(h-nh)/2, nw, nh);
  }

  function base(ctx, customImg) {
    const img = customImg || imgs.main;
    if (img) {
      ctx.save();
      ctx.filter = `brightness(${state.brightness}%) contrast(${state.contrast}%) saturate(${state.saturation}%)`;
      cover(ctx, img);
      ctx.restore();
    } else {
      ctx.fillStyle = "#222"; ctx.fillRect(0,0,ctx.canvas.width,ctx.canvas.height);
      fitText(ctx,"Upload photo",ctx.canvas.width/2,ctx.canvas.height/2,ctx.canvas.width-120,38,"Arial","700","center","#aaa");
    }
  }

  function gradients(ctx) {
    const w=ctx.canvas.width,h=ctx.canvas.height;
    let top=ctx.createLinearGradient(0,0,0,h*.35);
    top.addColorStop(0,"rgba(0,0,0,.55)"); top.addColorStop(1,"rgba(0,0,0,0)");
    ctx.fillStyle=top; ctx.fillRect(0,0,w,h*.45);
    let bot=ctx.createLinearGradient(0,h*.52,0,h);
    bot.addColorStop(0,"rgba(0,0,0,0)"); bot.addColorStop(1,"rgba(0,0,0,.72)");
    ctx.fillStyle=bot; ctx.fillRect(0,h*.5,w,h*.5);
  }

  function vignette(ctx) {
    const v = Number(state.vignette)/100;
    if (!v) return;
    const w=ctx.canvas.width,h=ctx.canvas.height;
    const g=ctx.createRadialGradient(w/2,h/2,Math.min(w,h)*.18,w/2,h/2,Math.max(w,h)*.78);
    g.addColorStop(0,"rgba(0,0,0,0)"); g.addColorStop(1,`rgba(0,0,0,${v})`);
    ctx.fillStyle=g; ctx.fillRect(0,0,w,h);
  }

  function drawLogo(ctx) {
    if (!state.showLogo) return;
    if (imgs.logo) {
      const sc = Math.min(180/imgs.logo.width, 80/imgs.logo.height);
      const nw = imgs.logo.width*sc, nh = imgs.logo.height*sc;
      ctx.drawImage(imgs.logo, pos.logo.x-nw, pos.logo.y, nw, nh);
    } else {
      fitText(ctx,state.brand.toUpperCase(),pos.logo.x,pos.logo.y+30,240,27,"Arial","800","right","#fff");
    }
  }

  function drawWatermark(ctx) {
    if (state.showWatermark) fitText(ctx,state.watermark,pos.watermark.x,pos.watermark.y,360,20,"Arial","500","right","rgba(255,255,255,.82)");
  }

  function privacy(ctx) {
    if (state.blurEnabled) {
      const b=pos.blur;
      ctx.save(); ctx.filter="blur(14px)";
      ctx.drawImage(ctx.canvas,b.x,b.y,b.w,b.h,b.x,b.y,b.w,b.h);
      ctx.restore();
      ctx.strokeStyle="rgba(255,255,255,.6)"; ctx.strokeRect(b.x,b.y,b.w,b.h);
    }
    if (state.faceHideEnabled) {
      const f=pos.face;
      ctx.fillStyle="rgba(0,0,0,.86)"; ctx.fillRect(f.x,f.y,f.w,f.h);
      fitText(ctx,"PRIVATE",f.x+f.w/2,f.y+f.h/2+8,f.w-20,26,"Arial","800","center","#fff");
    }
  }

  function drawQR(ctx) {
    if (!state.showQR || !qrImg) return;
    const img = new Image();
    img.onload = () => {};
    img.src = qrImg;
    if (img.complete) ctx.drawImage(img,pos.qr.x,pos.qr.y,pos.qr.w,pos.qr.h);
  }

  function delivery(ctx, customImg) {
    const w=ctx.canvas.width,h=ctx.canvas.height;
    if (state.template === "polaroid") return polaroid(ctx, customImg);
    base(ctx, customImg); gradients(ctx); vignette(ctx);
    ctx.strokeStyle = state.template==="luxury" ? "#caa85a" : "rgba(255,255,255,.9)";
    ctx.lineWidth=3; ctx.strokeRect(28,28,w-56,h-56);
    if (state.template==="minimal") { ctx.fillStyle="rgba(0,0,0,.78)"; ctx.fillRect(0,0,w,170); ctx.fillRect(0,h-180,w,180); }
    ctx.fillStyle="#caa85a"; ctx.fillRect(pos.title.x-25,pos.title.y-33,5,70);
    const s1=fitText(ctx,state.title.toUpperCase(),pos.title.x,pos.title.y,Math.min(570,w-pos.title.x-80),48,"Arial","900");
    const sy=pos.title.y+Math.max(38,s1*.95);
    const s2=fitText(ctx,state.subtitle.toUpperCase(),pos.title.x,sy,Math.min(570,w-pos.title.x-80),30,"Arial","400");
    fitText(ctx,state.model.toUpperCase(),pos.title.x,sy+Math.max(34,s2*1.2),Math.min(650,w-pos.title.x-80),22,"Arial","600","left","rgba(255,255,255,.86)");
    ctx.fillStyle="#fff"; ctx.font="italic 68px Brush Script MT, Segoe Script, cursive"; ctx.fillText("Thank you!",pos.thanks.x,pos.thanks.y);
    ctx.font="400 22px Arial"; ctx.fillText("ENJOY YOUR NEW RIDE",pos.thanks.x+2,pos.thanks.y+50);
    fitText(ctx,"Delivered by "+state.name,pos.name.x,pos.name.y,470,36,"Arial","700","right");
    fitText(ctx,"YOUR CAR ADVISOR",pos.name.x,pos.name.y+50,320,22,"Arial","400","right");
    drawLogo(ctx); drawWatermark(ctx); drawQR(ctx); privacy(ctx);
  }

  function polaroid(ctx, customImg) {
    const w=ctx.canvas.width,h=ctx.canvas.height,img=customImg||imgs.main;
    ctx.fillStyle="#f4f1ea"; ctx.fillRect(0,0,w,h);
    const m=70,px=m,py=m,pw=w-m*2,ph=Math.round(h*.66);
    ctx.shadowColor="rgba(0,0,0,.25)"; ctx.shadowBlur=22; ctx.shadowOffsetY=8;
    ctx.fillStyle="#fff"; ctx.fillRect(m-18,m-18,pw+36,ph+230); ctx.shadowColor="transparent";
    if (img) { ctx.save(); ctx.beginPath(); ctx.rect(px,py,pw,ph); ctx.clip(); cover(ctx,img,px,py,pw,ph); ctx.restore(); }
    fitText(ctx,"Delivered ♡",m,h-245,w-m*2,72,"Brush Script MT","400","left","#111");
    fitText(ctx,state.model.toUpperCase(),m,h-190,w-m*2,24,"Arial","800","left","#111");
    fitText(ctx,"Delivered by "+state.name,m,h-140,w-m*2,22,"Arial","600","left","#111");
    drawWatermark(ctx); privacy(ctx);
  }

  function promo(ctx, customImg) {
    const w=ctx.canvas.width,h=ctx.canvas.height,b=pos.box;
    base(ctx, customImg); ctx.fillStyle="rgba(0,0,0,.48)"; ctx.fillRect(0,0,w,h); gradients(ctx); vignette(ctx);
    ctx.fillStyle="#caa85a"; ctx.fillRect(0,0,w,16); drawLogo(ctx);
    fitText(ctx,state.model.toUpperCase(),70,95,w-140,50,"Arial","900");
    fitText(ctx,state.promoTitle.toUpperCase(),70,140,w-140,30,"Arial","500");
    ctx.fillStyle="rgba(0,0,0,.74)"; ctx.fillRect(b.x,b.y,b.w,b.h);
    ctx.strokeStyle="#caa85a"; ctx.lineWidth=3; ctx.strokeRect(b.x,b.y,b.w,b.h);
    fitText(ctx,state.promoOffer.toUpperCase(),b.x+b.w/2,b.y+90,b.w-60,74,"Arial","900","center","#caa85a");
    ctx.fillStyle="#fff"; ctx.font="500 28px Arial";
    state.gifts.split("\\n").filter(Boolean).slice(0,8).forEach((it,i)=>ctx.fillText("✓ "+it,b.x+45,b.y+150+i*35));
    drawWatermark(ctx); drawQR(ctx); privacy(ctx);
  }

  function compare(ctx) {
    const w=ctx.canvas.width,h=ctx.canvas.height;
    ctx.fillStyle="#111"; ctx.fillRect(0,0,w,h); vignette(ctx); drawLogo(ctx);
    fitText(ctx,state.compareTitle,w/2,90,w-120,48,"Arial","900","center","#fff");
    const top=150, boxH=Math.round(h*.38), gap=30, bw=(w-140-gap)/2;
    if (imgs.main) cover(ctx,imgs.main,70,top,bw,boxH); else { ctx.fillStyle="#333"; ctx.fillRect(70,top,bw,boxH); }
    if (imgs.second) cover(ctx,imgs.second,70+bw+gap,top,bw,boxH); else { ctx.fillStyle="#333"; ctx.fillRect(70+bw+gap,top,bw,boxH); }
    ctx.strokeStyle="#caa85a"; ctx.lineWidth=3; ctx.strokeRect(70,top,bw,boxH); ctx.strokeRect(70+bw+gap,top,bw,boxH);
    fitText(ctx,state.leftModel,70+bw/2,top+boxH+55,bw,34,"Arial","900","center");
    fitText(ctx,state.rightModel,70+bw+gap+bw/2,top+boxH+55,bw,34,"Arial","900","center");
    let y=top+boxH+115; ctx.font="500 24px Arial";
    state.compareList.split("\\n").filter(Boolean).slice(0,7).forEach(line=>{
      const [l,r]=line.split("|");
      ctx.fillStyle="rgba(255,255,255,.08)"; ctx.fillRect(70,y-28,w-140,44);
      ctx.fillStyle="#fff"; ctx.textAlign="center";
      ctx.fillText((l||"").trim(),70+bw/2,y); ctx.fillText((r||"").trim(),70+bw+gap+bw/2,y);
      y+=56;
    });
    ctx.textAlign="left"; drawWatermark(ctx);
  }

  function review(ctx, customImg) {
    const w=ctx.canvas.width,h=ctx.canvas.height;
    base(ctx, customImg); ctx.fillStyle="rgba(0,0,0,.62)"; ctx.fillRect(0,0,w,h); vignette(ctx); drawLogo(ctx);
    fitText(ctx,state.reviewTitle.toUpperCase(),70,120,w-140,44,"Arial","900");
    ctx.fillStyle="rgba(255,255,255,.92)"; ctx.fillRect(70,h*.42,w-140,360);
    ctx.strokeStyle="#caa85a"; ctx.lineWidth=4; ctx.strokeRect(70,h*.42,w-140,360);
    fitText(ctx,state.rating,w/2,h*.42+75,w-180,56,"Arial","900","center","#caa85a");
    wrapText(ctx,state.reviewText,120,h*.42+145,w-240,34,44,"#111","500");
    fitText(ctx,"— "+state.customerName,w-110,h*.42+310,w-240,28,"Arial","700","right","#111");
    drawWatermark(ctx);
  }

  function stats(ctx, customImg) {
    const w=ctx.canvas.width,h=ctx.canvas.height;
    base(ctx, customImg); ctx.fillStyle="rgba(0,0,0,.68)"; ctx.fillRect(0,0,w,h); vignette(ctx); drawLogo(ctx);
    ctx.fillStyle="#caa85a"; ctx.fillRect(70,88,120,8);
    fitText(ctx,state.statsTitle.toUpperCase(),70,160,w-140,48,"Arial","900");
    fitText(ctx,state.statsNumber,w/2,h*.43,w-160,190,"Arial","900","center","#caa85a");
    fitText(ctx,state.statsLabel.toUpperCase(),w/2,h*.50,w-160,36,"Arial","800","center");
    fitText(ctx,"Delivered by "+state.name,70,h-80,600,34,"Arial","700");
    drawWatermark(ctx);
  }

  function finance(ctx, customImg) {
    const w=ctx.canvas.width,h=ctx.canvas.height;
    base(ctx, customImg); ctx.fillStyle="rgba(0,0,0,.70)"; ctx.fillRect(0,0,w,h); vignette(ctx); drawLogo(ctx);
    const m=monthlyPayment(state.loanAmount,state.interestRate,state.tenureMonths);
    fitText(ctx,"MONTHLY INSTALLMENT",70,140,w-140,48,"Arial","900");
    fitText(ctx,`RM ${Math.round(m).toLocaleString()} / MONTH`,w/2,h*.42,w-140,86,"Arial","900","center","#caa85a");
    fitText(ctx,`${state.model} | Loan RM ${Number(state.loanAmount).toLocaleString()}`,w/2,h*.50,w-140,30,"Arial","700","center");
    fitText(ctx,`Rate ${state.interestRate}% | Tenure ${state.tenureMonths} months`,w/2,h*.55,w-140,26,"Arial","500","center");
    fitText(ctx,"DM / WhatsApp for full quotation",w/2,h*.70,w-140,36,"Arial","800","center","#fff");
    drawQR(ctx); drawWatermark(ctx);
  }

  function collage(ctx) {
    const w=ctx.canvas.width,h=ctx.canvas.height;
    ctx.fillStyle="#111"; ctx.fillRect(0,0,w,h); drawLogo(ctx);
    const photos=[imgs.main, imgs.second, ...imgs.batch].filter(Boolean).slice(0,9);
    const n=photos.length || 1, cols=n<=2?1:n<=4?2:3, rows=Math.ceil(n/cols);
    const gap=18, top=140, pad=50, cellW=(w-pad*2-gap*(cols-1))/cols, cellH=(h-top-140-gap*(rows-1))/rows;
    photos.forEach((img,i)=>cover(ctx,img,pad+(i%cols)*(cellW+gap),top+Math.floor(i/cols)*(cellH+gap),cellW,cellH));
    fitText(ctx,"JAX AUTO DELIVERY GALLERY",w/2,90,w-120,42,"Arial","900","center","#fff");
    drawWatermark(ctx);
  }

  function render(customImg) {
    const c=canvasRef.current; if(!c) return;
    setCanvasSize(); const ctx=c.getContext("2d"); ctx.clearRect(0,0,c.width,c.height);
    const mode=state.mode;
    if(mode==="delivery") delivery(ctx, customImg);
    if(mode==="promo") promo(ctx, customImg);
    if(mode==="compare") compare(ctx);
    if(mode==="review") review(ctx, customImg);
    if(mode==="stats") stats(ctx, customImg);
    if(mode==="finance") finance(ctx, customImg);
    if(mode==="collage") collage(ctx);
  }

  async function download() {
    render();
    const a=document.createElement("a");
    a.download="jax-auto-final.png";
    a.href=canvasRef.current.toDataURL("image/png",1);
    a.click();
  }

  async function downloadZip() {
    if(!imgs.batch.length) return alert("Upload batch photos first");
    const zip=new JSZip();
    for(let i=0;i<imgs.batch.length;i++){
      render(imgs.batch[i]);
      zip.file(`jax-auto-${i+1}.png`,canvasRef.current.toDataURL("image/png",1).split(",")[1],{base64:true});
      await new Promise(r=>setTimeout(r,40));
    }
    const blob=await zip.generateAsync({type:"blob"});
    const a=document.createElement("a");
    a.href=URL.createObjectURL(blob); a.download="jax-auto-batch.zip"; a.click();
    render();
  }

  return (
    <div className="app">
      <aside className="panel">
        <h1>JAX AUTO Delivery Studio</h1>
        <p>FINAL ULTIMATE · Canva-lite editor for car sales content</p>

        <div className="modes">
          {["delivery","promo","compare","review","stats","finance","collage"].map(m=>
            <button key={m} className={state.mode===m?"active":""} onClick={()=>update("mode",m)}>{m.toUpperCase()}</button>
          )}
        </div>

        <label>Main photo</label><input type="file" accept="image/*" onChange={e=>upload(e,"main")} />
        <label>Second photo / Compare</label><input type="file" accept="image/*" onChange={e=>upload(e,"second")} />
        <label>Logo</label><input type="file" accept="image/*" onChange={e=>upload(e,"logo")} />
        <label>Batch photos</label><input type="file" accept="image/*" multiple onChange={async e=>{
          const files=Array.from(e.target.files||[]).slice(0,50);
          const arr=[]; for(const f of files) arr.push(await fileToImage(f));
          setImgs(v=>({...v,batch:arr}));
        }} />

        <div className="grid2">
          <div><label>Template</label><select value={state.template} onChange={e=>update("template",e.target.value)}>
            <option value="modern">Modern Clean</option><option value="luxury">Luxury Dealer</option><option value="polaroid">Polaroid</option><option value="minimal">Minimal Dark</option>
          </select></div>
          <div><label>Ratio</label><select value={state.ratio} onChange={e=>update("ratio",e.target.value)}>
            {Object.keys(RATIOS).map(r=><option key={r}>{r}</option>)}
          </select></div>
        </div>

        <div className="grid2">
          <div><label>Brightness</label><input type="range" min="75" max="140" value={state.brightness} onChange={e=>update("brightness",e.target.value)} /></div>
          <div><label>Contrast</label><input type="range" min="75" max="150" value={state.contrast} onChange={e=>update("contrast",e.target.value)} /></div>
          <div><label>Saturation</label><input type="range" min="60" max="170" value={state.saturation} onChange={e=>update("saturation",e.target.value)} /></div>
          <div><label>Vignette</label><input type="range" min="0" max="90" value={state.vignette} onChange={e=>update("vignette",e.target.value)} /></div>
        </div>

        <div className="modelBtns">{MODELS.map(m=><button key={m} onClick={()=>update("model",m)}>{m}</button>)}</div>

        {[
          ["Title","title"],["Subtitle","subtitle"],["Model","model"],["Name","name"],["Brand","brand"],["Watermark","watermark"],["WhatsApp Link","whatsapp"],
          ["Promo Title","promoTitle"],["Promo Offer","promoOffer"],["Compare Title","compareTitle"],["Left Model","leftModel"],["Right Model","rightModel"],
          ["Review Title","reviewTitle"],["Review Text","reviewText"],["Customer Name","customerName"],["Stats Title","statsTitle"],["Stats Number","statsNumber"],["Stats Label","statsLabel"],
          ["Loan Amount","loanAmount"],["Interest Rate","interestRate"],["Tenure Months","tenureMonths"]
        ].map(([l,k])=><React.Fragment key={k}><label>{l}</label><input value={state[k]||""} onChange={e=>update(k,e.target.value)} /></React.Fragment>)}

        <label>Gift List</label><textarea value={state.gifts} onChange={e=>update("gifts",e.target.value)} />
        <label>Compare List: left | right</label><textarea value={state.compareList} onChange={e=>update("compareList",e.target.value)} />

        <div className="checks">
          <label><input type="checkbox" checked={state.showLogo} onChange={e=>update("showLogo",e.target.checked)} /> Show logo</label>
          <label><input type="checkbox" checked={state.showWatermark} onChange={e=>update("showWatermark",e.target.checked)} /> Show watermark</label>
          <label><input type="checkbox" checked={state.showQR} onChange={e=>update("showQR",e.target.checked)} /> Show QR</label>
          <label><input type="checkbox" checked={state.blurEnabled} onChange={e=>update("blurEnabled",e.target.checked)} /> Blur box</label>
          <label><input type="checkbox" checked={state.faceHideEnabled} onChange={e=>update("faceHideEnabled",e.target.checked)} /> Face hide box</label>
        </div>

        <button onClick={download}>Download PNG</button>
        <button className="secondary" onClick={downloadZip}>Batch ZIP Download</button>
        <button className="secondary" onClick={()=>{localStorage.removeItem("jax_final_state");location.reload();}}>Reset Preset</button>
      </aside>

      <main className="preview"><canvas ref={canvasRef}/></main>
    </div>
  );
}

createRoot(document.getElementById("root")).render(<App />);
